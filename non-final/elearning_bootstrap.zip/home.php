<?php
session_start();
include 'config.php';

// Check if the user is logged in
if (!isset($_SESSION["email"])) {
    header("Location: login.php");
    exit;
}

$email = $_SESSION["email"];
$user_query = "SELECT id FROM Users WHERE Email = '$email'";
$result = mysqli_query($conn, $user_query);
if ($result && mysqli_num_rows($result) > 0) {
    $user = mysqli_fetch_assoc($result);
    $_SESSION["user_id"] = $user["id"];
}

// Function to enroll the user in a course
function enrollCourse($conn, $user_id, $course_id) {
    // Check if the course ID and user ID are valid
    $course_query = "SELECT Course_Price FROM Courses WHERE Course_ID = $course_id";
    $result = mysqli_query($conn, $course_query);
    $course = mysqli_fetch_assoc($result);

    $user_query = "SELECT id FROM Users WHERE id = $user_id";
    $result = mysqli_query($conn, $user_query);
    $user = mysqli_fetch_assoc($result);

    if (!$course || !$user) {
        echo "Invalid course ID or user ID.";
        return;
    }

    // Check if the course is free
    $course_price = $course['Course_Price'];
    if ($course_price == 0) {
        echo "You have successfully enrolled in the course.";
    } else {
        // Check if the user has enough balance to enroll in the course
        $user_balance_query = "SELECT Balance FROM Users WHERE id = $user_id";
        $result = mysqli_query($conn, $user_balance_query);
        $user_balance = mysqli_fetch_assoc($result)['Balance'];

        if ($user_balance >= $course_price) {
            // Deduct the course price from the user's balance and enroll the user in the course
            $new_balance = $user_balance - $course_price;

            $enroll_query = "INSERT INTO Enrollments (User_ID, Course_ID) VALUES ($user_id, $course_id)";
            if (mysqli_query($conn, $enroll_query)) {
                $update_balance_query = "UPDATE Users SET Balance = $new_balance WHERE id = $user_id";
                if (mysqli_query($conn, $update_balance_query)) {
                    echo "You have successfully enrolled in the course.";
                } else {
                    echo "Error updating user balance: " . mysqli_error($conn);
                }
            } else {
                echo "Error enrolling in the course: " . mysqli_error($conn);
            }
        } else {
            echo "Insufficient balance. Please add funds to your account.";
        }
    }
}


// Function to fetch all courses from the database
function fetchCoursesFromDatabase($conn) {
    $query = "SELECT * FROM Courses";
    $result = mysqli_query($conn, $query);
    return mysqli_fetch_all($result, MYSQLI_ASSOC);
}

// Function to check if the user is already enrolled in a course
function isEnrolled($conn, $user_id, $course_id) {
    $enrollment_query = "SELECT * FROM Enrollments WHERE User_ID = $user_id AND Course_ID = $course_id";
    $result = mysqli_query($conn, $enrollment_query);
    return mysqli_num_rows($result) > 0;
}

// Fetch all courses from the database
$courses = fetchCoursesFromDatabase($conn);

// Handle the enrollment process
if (isset($_POST['enroll'])) {
    $course_id = $_POST['course_id'];
    $user_id = $_SESSION["user_id"];

    if (isEnrolled($conn, $user_id, $course_id)) {
        echo "You are already enrolled in this course.";
    } else {
        // Enroll the user in the course
        enrollCourse($conn, $user_id, $course_id);
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>View Courses</title>
</head>
<body>
    <?php include('navbar.php'); ?>

    <h2>View Courses</h2>
    <table>
        <tr>
            <th>Course Title</th>
            <th>Instructor</th>
            <th>Price</th>
            <th>Actions</th>
        </tr>
        <?php foreach ($courses as $course) : ?>
            <tr>
                <td><?php echo $course['Course_Title']; ?></td>
                <td><?php echo $course['Course_Instructor']; ?></td>
                <td><?php echo '$' . $course['Course_Price']; ?></td>
                <td>
                    <form action="<?php echo $_SERVER['PHP_SELF']; ?>" method="post">
                        <input type="hidden" name="course_id" value="<?php echo $course['Course_ID']; ?>">
                        <?php if (isEnrolled($conn, $_SESSION["user_id"], $course['Course_ID'])) : ?>
                            <button type="button" disabled>Enrolled</button>
                        <?php else : ?>
                            <input type="submit" name="enroll" value="Enroll">
                        <?php endif; ?>
                        <a href="course_details.php?id=<?php echo $course['Course_ID']; ?>">Details</a>
                    </form>
                </td>
            </tr>
        <?php endforeach; ?>
    </table>
</body>
</html>
