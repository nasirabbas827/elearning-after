<?php
session_start();
include 'config.php';

if (!isset($_SESSION["email"])) {
    header("Location: login.php");
    exit;
}

$user_id = $_SESSION["user_id"];

if (isset($_GET['course_id'])) {
    $course_id = $_GET['course_id'];

    // Fetch all quizzes for the course
    $quizzes_query = "SELECT * FROM Quizzes WHERE Course_ID = $course_id";
    $result = mysqli_query($conn, $quizzes_query);
    $quizzes = mysqli_fetch_all($result, MYSQLI_ASSOC);
}

// Handle quiz submission
if ($_SERVER["REQUEST_METHOD"] === "POST") {
    if (isset($_POST['quiz_id']) && isset($_POST['option'])) {
        $quiz_id = $_POST['quiz_id'];
        $selected_option = intval($_POST['option']); // Convert the selected option to an integer

        // Fetch quiz details
        $quiz_query = "SELECT * FROM Quizzes WHERE Quiz_ID = $quiz_id";
        $result = mysqli_query($conn, $quiz_query);
        $quiz = mysqli_fetch_assoc($result);

        if ($quiz) {
            // Check if the selected option is correct
            $correct_answer = intval($quiz['Quiz_Correct_Answer']); // Convert the correct answer to an integer
            $is_correct = ($selected_option === $correct_answer);

            // Store the quiz attempt in the database
            $insert_attempt_query = "INSERT INTO Quiz_Attempts (User_ID, Quiz_ID, Selected_Option, Is_Correct) VALUES ($user_id, $quiz_id, $selected_option, $is_correct)";
            mysqli_query($conn, $insert_attempt_query);
        }
    }
}

// Calculate total quizzes count
$total_quizzes = count($quizzes);

// Calculate total quiz attempts and correct attempts for the user
if (isset($quizzes)) {
    $total_attempts = 0;
    $correct_attempts = 0;

    foreach ($quizzes as $quiz) {
        $quiz_id = $quiz['Quiz_ID'];
        $quiz_attempts_query = "SELECT * FROM Quiz_Attempts WHERE User_ID = $user_id AND Quiz_ID = $quiz_id";
        $result = mysqli_query($conn, $quiz_attempts_query);
        $total_attempts += mysqli_num_rows($result);

        $correct_attempts_query = "SELECT * FROM Quiz_Attempts WHERE User_ID = $user_id AND Quiz_ID = $quiz_id AND Is_Correct = 1";
        $result = mysqli_query($conn, $correct_attempts_query);
        $correct_attempts += mysqli_num_rows($result);
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Attempt All Quizzes</title>
</head>
<body>
    <?php include('navbar.php'); ?>

    <h2>Attempt All Quizzes</h2>
    <?php if (isset($quizzes)) { ?>
        <?php foreach ($quizzes as $quiz) { ?>
            <div>
                <h4>Quiz Title: <?php echo $quiz['Quiz_Title']; ?></h4>
                <p>Quiz Question: <?php echo $quiz['Quiz_Question']; ?></p>
                <form action="attempt_quiz.php?course_id=<?php echo $course_id; ?>" method="post">
                    <input type="hidden" name="quiz_id" value="<?php echo $quiz['Quiz_ID']; ?>">
                    <?php
                    // Convert the quiz options from JSON to an array
                    $quiz_options_json = $quiz['Quiz_Options'];
                    $quiz_options = json_decode($quiz_options_json, true);

                    // Display the quiz options as radio buttons
                    foreach ($quiz_options as $key => $option) {
                        echo '<label>';
                        echo '<input type="radio" name="option" value="' . ($key + 1) . '">';
                        echo $option;
                        echo '</label><br>';
                    }
                    ?>
                    <button type="submit">Submit Answer</button>
                </form>
                <?php
                // Display the result message if available and if the quiz has been attempted
                if (isset($_POST['quiz_id']) && $_POST['quiz_id'] == $quiz['Quiz_ID']) {
                    $result_message = isset($is_correct) ? ($is_correct ? "Correct! Your answer is right." : "Incorrect! Your answer is wrong.") : "";
                    echo "<p>{$result_message}</p>";
                }
                ?>
            </div>
        <?php } ?>

        <?php if (isset($total_attempts) && $total_attempts > 0) { ?>
            <h3>Overall Result</h3>
            <p>Total Quiz Attempts: <?php echo $total_attempts; ?></p>
            <p>Correct Attempts: <?php echo $correct_attempts; ?></p>
            <p>Percentage: <?php echo ($correct_attempts / $total_attempts) * 100; ?>%</p>

            <?php if (($correct_attempts / $total_attempts) < 0.75) { ?>
                <p>Your score is less than 75% in one or more quizzes. You can retake the quizzes to improve your score.</p>
                <a href="attempt_quiz.php?course_id=<?php echo $course_id; ?>">Retake Quizzes</a>
            <?php } else if ($total_attempts === $total_quizzes) { ?>
                <?php if (isset($course_id)) { ?>
                    <p>Congratulations! You have completed all quizzes with a score greater than 75%. You can now download the course certificate.</p>
                    <a href="download_certificate.php?course_id=<?php echo $course_id; ?>">Download Course Certificate</a>
                <?php } ?>
            <?php } ?>
        <?php } ?>
    <?php } else { ?>
        <p>No quizzes found for this course.</p>
    <?php } ?>
</body>
</html>
